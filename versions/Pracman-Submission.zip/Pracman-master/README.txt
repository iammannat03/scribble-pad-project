Karun Singh (ks939)
Ashley Xue (ax25)
Peter Mocarski (pmm248)
Esther Jun (ejj35)

Instructions: Open index.html. Use the arrow keys to move forward and turn.

All music/sound effects taken from OpenGameArt.com, and is open source and free to use